how to install app and start to play  https://asciinema.org/a/qerTrmh4W3glqwz6WKtR2Clnu -
