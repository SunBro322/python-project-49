#!/usr/bin/env python3
def hello():
    print("Welcome to the Brain Games!")


def main():
    hello()

if __name__ == '__main__':
    main()