how to start to play app brain-even https://asciinema.org/a/qerTrmh4W3glqwz6WKtR2Clnu
how to start to play app brain-calc https://asciinema.org/a/LGWoeur1I11bKgxeI0lmFet3b
how to start to play app brain-gcd https://asciinema.org/a/mGihhU7WLeDlu8NGG91KiVCtu
how to start to play app brain-progression https://asciinema.org/a/135MEKiGpSnb4xZaFrU3wc6Up
