how to install app brain-even and start to play  https://asciinema.org/a/qerTrmh4W3glqwz6WKtR2Clnu
how to install app brain-calc and start to play  https://asciinema.org/a/LGWoeur1I11bKgxeI0lmFet3b
